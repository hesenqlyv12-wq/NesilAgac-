# Nəsil Ağacı — Android layihəsi

Bu layihə Kotlin + Jetpack Compose ilə hazırlanıb. Ailə üzvlərini əlavə etmək, redaktə etmək, silmək, şəkil seçmək/çəkmək, ailə əlaqələrinə keçmək və məlumatları telefonda saxlamaq funksiyaları var.

## Telefonda APK yaratmaq (kompütersiz)
1. GitHub hesabına daxil ol və yeni boş repository yarat.
2. ZIP-i açılmış layihənin bütün fayllarını repository-yə yüklə. `.github` qovluğundakı `android-apk.yml` faylını da daxil et.
3. Repository-də Actions bölməsini aç. `Build Nəsil Ağacı APK` iş axınını seç və `Run workflow` düyməsinə bas.
4. İş bitəndə həmin run səhifəsinin aşağısındakı Artifacts bölməsindən `NesilAgaci-debug-apk` faylını yüklə.
5. ZIP-i aç, `app-debug.apk` faylını telefonda aç və quraşdır.

Qeyd: APK bu ZIP-in içində hazır deyil; GitHub Actions onu buludda yaradır. GitHub hesabı və internet bağlantısı lazımdır.
