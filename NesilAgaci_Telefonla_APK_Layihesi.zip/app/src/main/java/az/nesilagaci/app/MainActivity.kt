package az.nesilagaci.app

import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import android.graphics.BitmapFactory
import android.net.Uri
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

private val Green = Color(0xFF07551F)
private val Gold = Color(0xFFFFC84A)

data class Person(
    val id: String = UUID.randomUUID().toString(),
    val firstName: String = "",
    val lastName: String = "",
    val age: String = "",
    val father: String = "",
    val mother: String = "",
    val spouse: String = "",
    val sons: String = "",
    val daughters: String = "",
    val isDeceased: Boolean = false,
    val extra: String = "",
    val photo: String = ""
) {
    val fullName: String get() = listOf(firstName, lastName).filter { it.isNotBlank() }.joinToString(" ")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NesilApp() }
    }
}

@Composable
fun NesilApp() {
    val context = LocalContext.current
    val people = remember { mutableStateListOf<Person>().apply { addAll(loadPeople(context)) } }
    var selected by remember { mutableStateOf<Person?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Person?>(null) }
    var query by remember { mutableStateOf("") }

    fun save() = savePeople(context, people.toList())
    fun findByName(name: String): Person? =
        people.firstOrNull { it.fullName.equals(name.trim(), ignoreCase = true) && name.isNotBlank() }

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Gold)) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFFF4F5EC)) {
            Column(Modifier.fillMaxSize()) {
                Column(
                    Modifier.fillMaxWidth().padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val logoId = remember(context) {
                        context.resources.getIdentifier("nesil_logo", "drawable", context.packageName)
                    }
                    if (logoId != 0) {
                        val bmp = remember(logoId) { BitmapFactory.decodeResource(context.resources, logoId) }
                        Image(bmp.asImageBitmap(), null, Modifier.size(112.dp))
                    }
                    Text("Nəsil Ağacı", style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold, color = Green)
                    Text("Ailənizin tarixçəsi", color = Color.DarkGray)
                }
                if (selected != null) {
                    PersonDetails(
                        person = selected!!,
                        onBack = { selected = null },
                        onEdit = { editing = selected; showForm = true },
                        onDelete = {
                            people.removeAll { it.id == selected!!.id }
                            save(); selected = null
                        },
                        onRelation = { name -> findByName(name)?.let { selected = it } }
                    )
                } else {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(query, { query = it }, Modifier.weight(1f),
                            label = { Text("Şəxs axtar") }, singleLine = true,
                            leadingIcon = { Icon(Icons.Default.Search, null) })
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { editing = null; showForm = true }) {
                            Icon(Icons.Default.Add, null); Text(" Əlavə et")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Ailə üzvləri (${people.size})", Modifier.padding(horizontal = 16.dp),
                        style = MaterialTheme.typography.titleMedium, color = Green, fontWeight = FontWeight.Bold)
                    if (people.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Hələ ailə üzvü əlavə edilməyib.\nBaşlamaq üçün “Əlavə et” düyməsinə basın.",
                                color = Color.DarkGray)
                        }
                    } else {
                        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                            items(people.filter { it.fullName.contains(query, true) }) { person ->
                                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { selected = person },
                                    colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        if (person.photo.isNotBlank() && File(person.photo).exists()) {
                                            val bmp = remember(person.photo) { BitmapFactory.decodeFile(person.photo) }
                                            if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.size(52.dp))
                                        } else {
                                            Icon(Icons.Default.AccountCircle, null, Modifier.size(48.dp), tint = Green)
                                        }
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(person.fullName.ifBlank { "Adsız şəxs" }, fontWeight = FontWeight.Bold)
                                            Text(if (person.isDeceased) "Vəfat edib" else "Sağdır",
                                                color = if (person.isDeceased) Color.Gray else Green)
                                        }
                                        Icon(Icons.Default.ChevronRight, null)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showForm) {
        PersonForm(
            initial = editing,
            onDismiss = { showForm = false; editing = null },
            onSave = { p ->
                val index = people.indexOfFirst { it.id == p.id }
                if (index >= 0) people[index] = p else people.add(p)
                save()
                if (selected?.id == p.id) selected = p
                showForm = false; editing = null
            }
        )
    }
}

@Composable
fun PersonDetails(person: Person, onBack: () -> Unit, onEdit: () -> Unit,
                  onDelete: () -> Unit, onRelation: (String) -> Unit) {
    var confirmDelete by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Text(" Geri") }
        if (person.photo.isNotBlank() && File(person.photo).exists()) {
            val bmp = remember(person.photo) { BitmapFactory.decodeFile(person.photo) }
            if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.fillMaxWidth().height(210.dp))
        }
        Text(person.fullName, style = MaterialTheme.typography.headlineSmall, color = Green, fontWeight = FontWeight.Bold)
        Text("Yaşı: ${person.age.ifBlank { "Qeyd edilməyib" }}")
        Text(if (person.isDeceased) "Vəfat edib" else "Sağdır")
        HorizontalDivider(Modifier.padding(vertical = 12.dp))
        Text("Ailə əlaqələri", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        RelationRow("Atası", person.father, onRelation)
        RelationRow("Anası", person.mother, onRelation)
        RelationRow("Həyat yoldaşı", person.spouse, onRelation)
        RelationRow("Oğlu", person.sons, onRelation)
        RelationRow("Qızı", person.daughters, onRelation)
        if (person.extra.isNotBlank()) {
            HorizontalDivider(Modifier.padding(vertical = 10.dp))
            Text("Əlavə məlumat", fontWeight = FontWeight.Bold)
            Text(person.extra)
        }
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onEdit, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Edit, null); Text(" Dəyiş")
            }
            OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.Delete, null); Text(" Sil")
            }
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Şəxs silinsin?") },
        text = { Text("Bu şəxsin məlumatları telefondan silinəcək.") },
        confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text("Sil") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Ləğv et") } }
    )
}

@Composable
fun RelationRow(label: String, name: String, onRelation: (String) -> Unit) {
    if (name.isNotBlank()) {
        Row(Modifier.fillMaxWidth().clickable { onRelation(name) }.padding(vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("$label: ", fontWeight = FontWeight.Medium)
            Text(name, color = Green, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.OpenInNew, null, tint = Green)
        }
    } else {
        Text("$label: qeyd edilməyib", Modifier.padding(vertical = 5.dp), color = Color.Gray)
    }
}

@Composable
fun PersonForm(initial: Person?, onDismiss: () -> Unit, onSave: (Person) -> Unit) {
    val context = LocalContext.current
    var first by remember { mutableStateOf(initial?.firstName ?: "") }
    var last by remember { mutableStateOf(initial?.lastName ?: "") }
    var age by remember { mutableStateOf(initial?.age ?: "") }
    var father by remember { mutableStateOf(initial?.father ?: "") }
    var mother by remember { mutableStateOf(initial?.mother ?: "") }
    var spouse by remember { mutableStateOf(initial?.spouse ?: "") }
    var sons by remember { mutableStateOf(initial?.sons ?: "") }
    var daughters by remember { mutableStateOf(initial?.daughters ?: "") }
    var deceased by remember { mutableStateOf(initial?.isDeceased ?: false) }
    var extra by remember { mutableStateOf(initial?.extra ?: "") }
    var photo by remember { mutableStateOf(initial?.photo ?: "") }
    var error by remember { mutableStateOf(false) }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) photo = copyUriToInternal(context, uri) ?: photo
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap: Bitmap? ->
        if (bitmap != null) photo = saveBitmap(context, bitmap) ?: photo
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Yeni şəxs" else "Məlumatları dəyiş") },
        text = {
            Column(Modifier.heightIn(max = 540.dp).verticalScroll(rememberScrollState())) {
                OutlinedTextField(first, { first = it }, label = { Text("Adı *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(last, { last = it }, label = { Text("Soyadı") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(age, { age = it }, label = { Text("Yaşı") }, modifier = Modifier.fillMaxWidth())
                Text("Ailə əlaqələri", Modifier.padding(top = 10.dp, bottom = 4.dp), fontWeight = FontWeight.Bold)
                OutlinedTextField(father, { father = it }, label = { Text("Atasının adı və soyadı") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(mother, { mother = it }, label = { Text("Anasının adı və soyadı") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(spouse, { spouse = it }, label = { Text("Həyat yoldaşı") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(sons, { sons = it }, label = { Text("Oğlu (ad və soyad)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(daughters, { daughters = it }, label = { Text("Qızı (ad və soyad)") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(deceased, { deceased = it })
                    Text("Vəfat edib")
                }
                OutlinedTextField(extra, { extra = it }, label = { Text("Əlavə məlumat") },
                    modifier = Modifier.fillMaxWidth(), minLines = 2)
                Text("Şəkil", Modifier.padding(top = 8.dp), fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { gallery.launch("image/*") }) { Icon(Icons.Default.PhotoLibrary, null); Text(" Qalereya") }
                    OutlinedButton(onClick = { camera.launch(null) }) { Icon(Icons.Default.CameraAlt, null); Text(" Kamera") }
                }
                if (photo.isNotBlank()) Text("Şəkil əlavə olunub", color = Green)
                if (error) Text("Adı daxil et.", color = Color.Red)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (first.isBlank()) error = true else onSave(Person(
                    id = initial?.id ?: UUID.randomUUID().toString(),
                    firstName = first.trim(), lastName = last.trim(), age = age.trim(),
                    father = father.trim(), mother = mother.trim(), spouse = spouse.trim(),
                    sons = sons.trim(), daughters = daughters.trim(), isDeceased = deceased,
                    extra = extra.trim(), photo = photo
                ))
            }) { Text("Yadda saxla") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Ləğv et") } }
    )
}

fun loadPeople(context: Context): List<Person> = try {
    val json = context.getSharedPreferences("nesil", Context.MODE_PRIVATE).getString("people", "[]") ?: "[]"
    val type = object : TypeToken<List<Person>>() {}.type
    Gson().fromJson<List<Person>>(json, type) ?: emptyList()
} catch (_: Exception) { emptyList() }

fun savePeople(context: Context, people: List<Person>) {
    context.getSharedPreferences("nesil", Context.MODE_PRIVATE).edit()
        .putString("people", Gson().toJson(people)).apply()
}

fun copyUriToInternal(context: Context, uri: Uri): String? = try {
    val file = File(context.filesDir, "photo_${UUID.randomUUID()}.jpg")
    context.contentResolver.openInputStream(uri)?.use { input ->
        FileOutputStream(file).use { output -> input.copyTo(output) }
    }
    file.absolutePath
} catch (_: Exception) { null }

fun saveBitmap(context: Context, bitmap: Bitmap): String? = try {
    val file = File(context.filesDir, "photo_${UUID.randomUUID()}.jpg")
    FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it) }
    file.absolutePath
} catch (_: Exception) { null }
